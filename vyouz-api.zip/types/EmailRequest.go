package types

type EmailRequest struct {
	Email string
}
