package types

type Transaction struct {
	Type          string
	Amount        float64
	PaymentMethod string
}
