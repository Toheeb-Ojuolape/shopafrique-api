# To start program like nodemon 

compiledaemon --command="./shopafrique-api"